module.exports = {
  key: "gama-2022",
};
